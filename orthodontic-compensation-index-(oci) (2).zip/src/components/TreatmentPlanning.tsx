import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, TextInput, ActivityIndicator } from 'react-native';
import { 
  Award, 
  Activity, 
  Compass, 
  Sliders, 
  Plus, 
  ChevronDown, 
  Check, 
  Zap, 
  CheckCircle, 
  TrendingUp, 
  User, 
  ShieldAlert, 
  Bookmark, 
  Settings, 
  Layers, 
  Info,
  Calendar,
  Sparkles
} from 'lucide-react-native';
import tw from 'twrnc';
import { Assessment, PatientDetails, CephalometricInput, OciResult, AdvancedClinicalIntelligence } from '../types';
import { generateTreatmentPlan, TreatmentPlanResult, TreatmentPlanningOptions } from '../treatmentPlanner';

interface TreatmentPlanningProps {
  savedAssessments: Assessment[];
  onUpdateAssessment: (assessment: Assessment) => void;
  activeAssessmentId?: string | null;
}

export default function TreatmentPlanning({ savedAssessments, onUpdateAssessment, activeAssessmentId }: TreatmentPlanningProps) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showPatientSelect, setShowPatientSelect] = useState(false);

  // Treatment Options state
  const [ageGroup, setAgeGroup] = useState<'growing' | 'adult'>('adult');
  const [crowdingSeverity, setCrowdingSeverity] = useState<'none' | 'mild' | 'moderate' | 'severe'>('none');
  const [spacingSeverity, setSpacingSeverity] = useState<'none' | 'mild' | 'moderate' | 'severe'>('none');
  const [archDiscrepancy, setArchDiscrepancy] = useState<number>(0);
  const [clinicianOverride, setClinicianOverride] = useState<string>('');
  const [isSaved, setIsSaved] = useState(false);

  // Initialize selected patient
  useEffect(() => {
    if (activeAssessmentId) {
      setSelectedId(activeAssessmentId);
    } else if (savedAssessments.length > 0 && !selectedId) {
      setSelectedId(savedAssessments[0].id);
    }
  }, [activeAssessmentId, savedAssessments]);

  // Load and pre-populate options when selected patient changes
  useEffect(() => {
    if (!selectedId) return;
    const assessment = savedAssessments.find(a => a.id === selectedId);
    if (!assessment) return;

    const details = assessment.patientDetails;
    const adv = assessment.advanced;

    // Smart defaults based on patient age and properties
    const age = Number(details.age) || 0;
    setAgeGroup(age > 0 && age < 16 ? 'growing' : 'adult');

    const crowdingSpacing = details.crowdingSpacing;
    if (crowdingSpacing === 'Crowding') {
      setCrowdingSeverity('moderate');
      setSpacingSeverity('none');
    } else if (crowdingSpacing === 'Spacing') {
      setSpacingSeverity('moderate');
      setCrowdingSeverity('none');
    } else {
      setCrowdingSeverity('none');
      setSpacingSeverity('none');
    }

    setArchDiscrepancy(0);
    setClinicianOverride(adv?.finalClinicalSummary || details.clinicalNotes || '');
    setIsSaved(false);
  }, [selectedId, savedAssessments]);

  // Find currently selected assessment
  const activeAssessment = savedAssessments.find(a => a.id === selectedId);

  // Safe numerical fallback helper
  const getNumVal = (val: string | number | undefined, fallback = 0): number => {
    if (val === undefined || val === '') return fallback;
    const n = Number(val);
    return isNaN(n) ? fallback : n;
  };

  // Run the treatment planning rules engine dynamically
  let treatmentPlan: TreatmentPlanResult | null = null;
  if (activeAssessment) {
    const options: TreatmentPlanningOptions = {
      ageGroup,
      crowdingSeverity,
      spacingSeverity,
      archDiscrepancy
    };
    treatmentPlan = generateTreatmentPlan(
      activeAssessment.patientDetails,
      activeAssessment.cephalometricInput,
      activeAssessment.ociResult,
      options
    );
  }

  const handleSavePlan = () => {
    if (!activeAssessment || !treatmentPlan) return;

    // Build the updated advanced data structure
    const updatedAdvanced: AdvancedClinicalIntelligence = {
      ...(activeAssessment.advanced || {}),
      complexity: treatmentPlan.treatmentComplexity,
      difficultyScore: treatmentPlan.treatmentComplexity === 'Severe / Surgical' ? '9' : treatmentPlan.treatmentComplexity === 'Complex' ? '7' : '4',
      extractionRecommendation: treatmentPlan.orthodonticCamouflage.extractionConsideration.includes('extraction is highly indicated') ? 'Extraction' : 'Non-Extraction',
      extractionReason: treatmentPlan.orthodonticCamouflage.extractionConsideration,
      surgeryRecommendation: treatmentPlan.surgicalOrthodontics.applicable ? 'Surgical Correction' : 'Orthodontic Camouflage',
      surgeryReason: treatmentPlan.surgicalOrthodontics.orthognathicReferralConsideration,
      primaryObjectives: treatmentPlan.treatmentObjectives[0] || 'Align dental arches.',
      secondaryObjectives: treatmentPlan.treatmentObjectives[1] || 'Optimize sagittal intercuspation.',
      treatmentSequence: 'Phase 1: Levelling & Alignment -> Phase 2: Space Closure -> Phase 3: Finishing',
      finalClinicalSummary: clinicianOverride || treatmentPlan.severityAssessment,
      growthStatus: ageGroup === 'growing' ? 'Active Growth Stage (Peak Vel.)' : 'Skeletally Mature (Completed)',
    };

    const updatedAssessment: Assessment = {
      ...activeAssessment,
      advanced: updatedAdvanced,
      patientDetails: {
        ...activeAssessment.patientDetails,
        clinicalNotes: clinicianOverride || activeAssessment.patientDetails.clinicalNotes
      }
    };

    onUpdateAssessment(updatedAssessment);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  if (savedAssessments.length === 0) {
    return (
      <View style={tw`flex-1 justify-center items-center p-6 bg-[#050814]`}>
        <View style={tw`bg-[#0B1020] border border-white/5 rounded-3xl p-8 max-w-md w-full items-center text-center shadow-2xl`}>
          <ShieldAlert size={48} color="#EF4444" style={tw`mb-4`} />
          <Text style={tw`text-lg font-black text-white text-center`}>No Patients Found</Text>
          <Text style={tw`text-xs text-slate-400 text-center mt-2 leading-relaxed`}>
            Please complete a Cephalometric Analysis and OCI assessment first to access the dynamic Treatment Planner.
          </Text>
        </View>
      </View>
    );
  }

  const complexityColor = (comp?: string) => {
    switch (comp) {
      case 'Severe / Surgical': return '#EF4444';
      case 'Complex': return '#F59E0B';
      case 'Moderate': return '#14B8A6';
      default: return '#10B981';
    }
  };

  const complexityBg = (comp?: string) => {
    switch (comp) {
      case 'Severe / Surgical': return 'bg-red-500/10 border-red-500/25';
      case 'Complex': return 'bg-amber-500/10 border-amber-500/25';
      case 'Moderate': return 'bg-teal-500/10 border-teal-500/25';
      default: return 'bg-emerald-500/10 border-emerald-500/25';
    }
  };

  return (
    <ScrollView style={tw`flex-1 bg-[#050814]`} contentContainerStyle={tw`pb-20`}>
      <View style={tw`p-4 md:p-6 space-y-6 max-w-7xl mx-auto w-full`}>
        
        {/* ====================================================
            HEADER BAR & PATIENT SELECTOR
           ==================================================== */}
        <View style={tw`flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#0B1020]/40 p-6 rounded-3xl border border-white/5`}>
          <View style={tw`space-y-1`}>
            <View style={tw`flex-row items-center space-x-2`}>
              <Layers size={16} color="#14B8A6" />
              <Text style={tw`text-xs font-black text-teal-400 font-mono uppercase tracking-wider`}>Orthodontic Clinical Decision Support System</Text>
            </View>
            <Text style={tw`text-2xl font-black text-white`}>Treatment Planner & Biomechanics Engine</Text>
          </View>

          {/* Patient dropdown selection */}
          <View style={tw`relative w-full md:w-72`}>
            <Pressable
              onPress={() => setShowPatientSelect(!showPatientSelect)}
              style={tw`w-full bg-[#0B1226] border border-white/10 rounded-2xl px-4 py-3 flex-row justify-between items-center`}
            >
              <View style={tw`flex-row items-center space-x-2.5`}>
                <User size={14} color="#64748B" />
                <Text style={tw`text-xs font-extrabold text-white`}>
                  {activeAssessment ? activeAssessment.patientDetails.name : 'Select Patient'}
                </Text>
              </View>
              <ChevronDown size={14} color="#14B8A6" />
            </Pressable>

            {showPatientSelect && (
              <View style={tw`absolute top-14 left-0 right-0 bg-[#0B1020] border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-50`}>
                {savedAssessments.map((item) => (
                  <Pressable
                    key={item.id}
                    onPress={() => {
                      setSelectedId(item.id);
                      setShowPatientSelect(false);
                    }}
                    style={tw`px-4 py-3.5 border-b border-white/5 hover:bg-white/3 flex-row justify-between items-center`}
                  >
                    <View>
                      <Text style={tw`text-xs font-black text-white`}>{item.patientDetails.name}</Text>
                      <Text style={tw`text-[9px] text-slate-500 mt-0.5`}>ID: {item.patientDetails.caseNumber || 'N/A'}</Text>
                    </View>
                    {selectedId === item.id && <Check size={12} color="#14B8A6" />}
                  </Pressable>
                ))}
              </View>
            )}
          </View>
        </View>

        {activeAssessment && treatmentPlan && (
          <View style={tw`grid grid-cols-1 lg:grid-cols-3 gap-6 items-start`}>
            
            {/* ====================================================
                LEFT COLUMN: INTERACTIVE CLINICAL INPUTS
               ==================================================== */}
            <View style={tw`lg:col-span-1 space-y-6`}>
              
              {/* Patient Profile Card */}
              <View style={tw`bg-[#0B1020] rounded-3xl p-5 border border-white/5 space-y-4`}>
                <Text style={tw`text-[9px] font-black text-slate-500 uppercase tracking-widest font-mono border-b border-white/5 pb-2`}>
                  Active Patient Demographics
                </Text>
                
                <View style={tw`space-y-3`}>
                  <View style={tw`flex-row justify-between items-center`}>
                    <Text style={tw`text-xs text-slate-400`}>Gender / Age</Text>
                    <Text style={tw`text-xs font-bold text-white`}>
                      {activeAssessment.patientDetails.gender} • {activeAssessment.patientDetails.age} Y
                    </Text>
                  </View>
                  <View style={tw`flex-row justify-between items-center`}>
                    <Text style={tw`text-xs text-slate-400`}>Diagnosis Base</Text>
                    <Text style={tw`text-xs font-bold text-teal-400`}>
                      Skeletal {activeAssessment.patientDetails.diagnosis || 'Class I'}
                    </Text>
                  </View>
                  <View style={tw`flex-row justify-between items-center`}>
                    <Text style={tw`text-xs text-slate-400`}>Dentition Phase</Text>
                    <Text style={tw`text-xs font-bold text-[#22D3EE]`}>
                      {activeAssessment.patientDetails.dentitionPhase || 'Permanent Dentition'}
                    </Text>
                  </View>
                  <View style={tw`flex-row justify-between items-center`}>
                    <Text style={tw`text-xs text-slate-400`}>OCI Score</Text>
                    <Text style={tw`text-xs font-black text-white font-mono`}>
                      {activeAssessment.ociResult.totalScore}%
                    </Text>
                  </View>
                </View>
              </View>

              {/* Dynamic Planning Variables */}
              <View style={tw`bg-[#0B1020] rounded-3xl p-6 border border-white/5 space-y-6`}>
                <View style={tw`flex-row items-center space-x-2 border-b border-white/5 pb-3`}>
                  <Sliders size={14} color="#14B8A6" />
                  <Text style={tw`text-[10px] font-black text-slate-200 uppercase tracking-widest font-mono`}>
                    Clinical Variables
                  </Text>
                </View>

                {/* 1. Growth Stage Modification Toggle */}
                <View style={tw`space-y-2`}>
                  <Text style={tw`text-xs font-extrabold text-slate-300`}>Physiological Growth Potential</Text>
                  <View style={tw`flex-row gap-2.5`}>
                    {[
                      { key: 'growing', label: 'Growing (Interceptive)', desc: 'Peak growth' },
                      { key: 'adult', label: 'Adult (Skeletally Mature)', desc: 'Completed' }
                    ].map((opt) => (
                      <Pressable
                        key={opt.key}
                        onPress={() => setAgeGroup(opt.key as 'growing' | 'adult')}
                        style={tw`flex-1 p-3 rounded-2xl border ${
                          ageGroup === opt.key 
                            ? 'bg-[#14B8A6]/10 border-[#14B8A6]' 
                            : 'bg-black/30 border-white/5'
                        }`}
                      >
                        <Text style={tw`text-xs font-black text-center ${ageGroup === opt.key ? 'text-white' : 'text-slate-400'}`}>
                          {opt.label}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>

                {/* 2. Crowding Selector */}
                <View style={tw`space-y-2`}>
                  <Text style={tw`text-xs font-extrabold text-slate-300`}>Arch Crowding Severity</Text>
                  <View style={tw`flex-row flex-wrap gap-2`}>
                    {(['none', 'mild', 'moderate', 'severe'] as const).map((sev) => (
                      <Pressable
                        key={sev}
                        onPress={() => {
                          setCrowdingSeverity(sev);
                          if (sev !== 'none') setSpacingSeverity('none');
                        }}
                        style={tw`px-3 py-2 rounded-xl border capitalize ${
                          crowdingSeverity === sev 
                            ? 'bg-amber-500/10 border-amber-500/40 text-amber-300' 
                            : 'bg-black/30 border-white/5 text-slate-400'
                        }`}
                      >
                        <Text style={tw`text-[10px] font-bold text-center ${crowdingSeverity === sev ? 'text-amber-400' : 'text-slate-400'}`}>
                          {sev}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>

                {/* 3. Spacing Selector */}
                <View style={tw`space-y-2`}>
                  <Text style={tw`text-xs font-extrabold text-slate-300`}>Arch Spacing Severity</Text>
                  <View style={tw`flex-row flex-wrap gap-2`}>
                    {(['none', 'mild', 'moderate', 'severe'] as const).map((sev) => (
                      <Pressable
                        key={sev}
                        onPress={() => {
                          setSpacingSeverity(sev);
                          if (sev !== 'none') setCrowdingSeverity('none');
                        }}
                        style={tw`px-3 py-2 rounded-xl border capitalize ${
                          spacingSeverity === sev 
                            ? 'bg-blue-500/10 border-blue-500/40 text-blue-300' 
                            : 'bg-black/30 border-white/5 text-slate-400'
                        }`}
                      >
                        <Text style={tw`text-[10px] font-bold text-center ${spacingSeverity === sev ? 'text-blue-400' : 'text-slate-400'}`}>
                          {sev}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>

                {/* 4. Arch Discrepancy Stepper */}
                <View style={tw`space-y-2.5`}>
                  <Text style={tw`text-xs font-extrabold text-slate-300`}>Custom Space Discrepancy (mm)</Text>
                  <View style={tw`flex-row items-center justify-between bg-black/40 border border-white/5 p-2 rounded-2xl`}>
                    <Pressable
                      onPress={() => setArchDiscrepancy(prev => prev - 1)}
                      style={tw`w-10 h-10 bg-white/5 rounded-xl justify-center items-center`}
                    >
                      <Text style={tw`text-white font-black text-sm`}>-</Text>
                    </Pressable>
                    <Text style={tw`text-sm font-black text-white font-mono`}>
                      {archDiscrepancy > 0 ? `+${archDiscrepancy}` : archDiscrepancy} mm
                    </Text>
                    <Pressable
                      onPress={() => setArchDiscrepancy(prev => prev + 1)}
                      style={tw`w-10 h-10 bg-white/5 rounded-xl justify-center items-center`}
                    >
                      <Text style={tw`text-white font-black text-sm`}>+</Text>
                    </Pressable>
                  </View>
                  <Text style={tw`text-[9px] text-slate-500 font-medium`}>
                    Positive denotes spacing excess; negative denotes crowding deficit in mm.
                  </Text>
                </View>
              </View>

            </View>

            {/* ====================================================
                RIGHT COLUMN: DECISION PLAN OUTPUT PANEL
               ==================================================== */}
            <View style={tw`lg:col-span-2 space-y-6`}>
              
              {/* Complexity Banner */}
              <View style={tw`p-5 rounded-[24px] border ${complexityBg(treatmentPlan.treatmentComplexity)} flex-row justify-between items-center gap-4`}>
                <View style={tw`space-y-1`}>
                  <Text style={tw`text-[9px] font-black text-slate-400 uppercase tracking-widest font-mono`}>OCI COMPLEXITY CLASSIFICATION</Text>
                  <Text style={[tw`text-xl font-black`, { color: complexityColor(treatmentPlan.treatmentComplexity) }]}>
                    {treatmentPlan.treatmentComplexity} malocclusion
                  </Text>
                  <Text style={tw`text-xs text-slate-300 max-w-lg leading-relaxed`}>
                    {treatmentPlan.severityAssessment}
                  </Text>
                </View>
                <View style={tw`w-12 h-12 rounded-full items-center justify-center bg-white/5 border border-white/10`}>
                  <Award size={20} color={complexityColor(treatmentPlan.treatmentComplexity)} />
                </View>
              </View>

              {/* Problem List and Objectives */}
              <View style={tw`grid grid-cols-1 md:grid-cols-2 gap-5`}>
                
                {/* Clinical Problem List */}
                <View style={tw`bg-[#0B1020] rounded-3xl p-5 border border-white/5 space-y-3`}>
                  <Text style={tw`text-[9px] font-black text-slate-400 uppercase tracking-widest font-mono border-b border-white/5 pb-2`}>
                    Diagnostic Problem List
                  </Text>
                  <ScrollView style={{ maxHeight: 180 }}>
                    <View style={tw`space-y-2`}>
                      {treatmentPlan.problemList.map((problem, i) => (
                        <View key={i} style={tw`flex-row items-start space-x-2`}>
                          <Text style={tw`text-rose-500 font-bold text-xs mt-0.5`}>•</Text>
                          <Text style={tw`text-xs font-semibold text-slate-300 leading-relaxed`}>{problem}</Text>
                        </View>
                      ))}
                    </View>
                  </ScrollView>
                </View>

                {/* Objectives */}
                <View style={tw`bg-[#0B1020] rounded-3xl p-5 border border-white/5 space-y-3`}>
                  <Text style={tw`text-[9px] font-black text-slate-400 uppercase tracking-widest font-mono border-b border-white/5 pb-2`}>
                    Primary Treatment Objectives
                  </Text>
                  <ScrollView style={{ maxHeight: 180 }}>
                    <View style={tw`space-y-2`}>
                      {treatmentPlan.treatmentObjectives.map((obj, i) => (
                        <View key={i} style={tw`flex-row items-start space-x-2`}>
                          <Text style={tw`text-emerald-400 font-bold text-xs mt-0.5`}>✓</Text>
                          <Text style={tw`text-xs font-semibold text-slate-300 leading-relaxed`}>{obj}</Text>
                        </View>
                      ))}
                    </View>
                  </ScrollView>
                </View>

              </View>

              {/* Orthodontic Camouflage (Extraction & space planning) */}
              <View style={tw`bg-[#0B1020] rounded-3xl p-6 border border-white/5 space-y-4`}>
                <View style={tw`flex-row items-center space-x-2 border-b border-white/5 pb-3`}>
                  <Compass size={14} color="#14B8A6" />
                  <Text style={tw`text-[10px] font-black text-slate-200 uppercase tracking-widest font-mono`}>
                    ORTHODONTIC CAMOUFLAGE & BIOMECHANICS
                  </Text>
                </View>

                <View style={tw`grid grid-cols-1 md:grid-cols-2 gap-4`}>
                  <View style={tw`bg-black/30 p-4 rounded-2xl border border-white/5 space-y-1.5`}>
                    <Text style={tw`text-[8px] text-slate-500 font-bold uppercase tracking-wider`}>Extraction Assessment</Text>
                    <Text style={tw`text-xs font-black text-white`}>
                      {treatmentPlan.orthodonticCamouflage.extractionConsideration.includes('Non-extraction') ? 'Non-Extraction' : 'Extraction Advised'}
                    </Text>
                    <Text style={tw`text-[11px] text-slate-400 leading-relaxed`}>
                      {treatmentPlan.orthodonticCamouflage.extractionConsideration}
                    </Text>
                  </View>

                  <View style={tw`bg-black/30 p-4 rounded-2xl border border-white/5 space-y-1.5`}>
                    <Text style={tw`text-[8px] text-slate-500 font-bold uppercase tracking-wider`}>Space Management</Text>
                    <Text style={tw`text-[11px] text-slate-400 leading-relaxed`}>
                      {treatmentPlan.orthodonticCamouflage.spaceManagement}
                    </Text>
                  </View>
                </View>

                <View style={tw`bg-[#14B8A6]/5 p-4 rounded-2xl border border-[#14B8A6]/10 space-y-1.5`}>
                  <Text style={tw`text-[8px] text-teal-400 font-black uppercase tracking-wider`}>Dental Compensation Strategy</Text>
                  <Text style={tw`text-xs text-slate-200 leading-relaxed`}>
                    {treatmentPlan.orthodonticCamouflage.incisorCompensationStrategies}
                  </Text>
                </View>
              </View>

              {/* Growth Modification or Surgical Protocols */}
              {ageGroup === 'growing' ? (
                <View style={tw`bg-[#0B1020] rounded-3xl p-6 border border-white/5 space-y-4`}>
                  <View style={tw`flex-row items-center space-x-2 border-b border-white/5 pb-3`}>
                    <TrendingUp size={14} color="#22D3EE" />
                    <Text style={tw`text-[10px] font-black text-slate-200 uppercase tracking-widest font-mono`}>
                      ORTHOPEDIC GROWTH MODIFICATION BLUEPRINT
                    </Text>
                  </View>
                  <View style={tw`space-y-3`}>
                    <View style={tw`bg-[#22D3EE]/5 p-4 rounded-2xl border border-[#22D3EE]/15 space-y-1`}>
                      <Text style={tw`text-[8px] text-cyan-400 font-black uppercase tracking-wider`}>Developmental Intervention Timing</Text>
                      <Text style={tw`text-xs text-slate-200 leading-relaxed`}>{treatmentPlan.growthModification.timingConsideration}</Text>
                    </View>

                    <View style={tw`space-y-2`}>
                      <Text style={tw`text-xs font-extrabold text-slate-300`}>Growth Modification Interventions</Text>
                      {treatmentPlan.growthModification.growthGuidanceOptions.map((opt, idx) => (
                        <View key={idx} style={tw`flex-row items-start space-x-2 bg-black/25 p-3 rounded-xl border border-white/5`}>
                          <Text style={tw`text-cyan-400 font-black text-xs`}>•</Text>
                          <Text style={tw`text-xs text-slate-300 flex-1 leading-relaxed`}>{opt}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                </View>
              ) : treatmentPlan.surgicalOrthodontics.applicable ? (
                <View style={tw`bg-red-950/15 rounded-3xl p-6 border border-red-500/20 space-y-4`}>
                  <View style={tw`flex-row items-center space-x-2 border-b border-red-500/10 pb-3`}>
                    <ShieldAlert size={14} color="#EF4444" />
                    <Text style={tw`text-[10px] font-black text-rose-400 uppercase tracking-widest font-mono`}>
                      SURGICAL ORTHODONTICS INDICATED (SEVERE MALOCCLUSION)
                    </Text>
                  </View>
                  <Text style={tw`text-xs text-slate-300 leading-relaxed`}>
                    {treatmentPlan.surgicalOrthodontics.orthognathicReferralConsideration}
                  </Text>
                  <View style={tw`bg-black/35 p-4 rounded-2xl border border-white/5`}>
                    <Text style={tw`text-[8px] text-slate-400 font-bold uppercase tracking-wider`}>Presurgical Decompensation Guidance</Text>
                    <Text style={tw`text-xs text-slate-300 leading-relaxed mt-1`}>
                      Reversing dentoalveolar compensations is mandatory prior to orthognathic surgery. Lower incisors must be uprighted back to 90° IMPA, and upper incisors coordinates re-established to permit full surgical jaw correction.
                    </Text>
                  </View>
                </View>
              ) : null}

              {/* Appliance suggestion cards */}
              <View style={tw`bg-[#0B1020] rounded-3xl p-6 border border-white/5 space-y-4`}>
                <View style={tw`flex-row items-center space-x-2 border-b border-white/5 pb-3`}>
                  <Zap size={14} color="#14B8A6" />
                  <Text style={tw`text-[10px] font-black text-slate-200 uppercase tracking-widest font-mono`}>
                    RECOMENDED CLINICAL APPLIANCES
                  </Text>
                </View>

                <View style={tw`grid grid-cols-1 md:grid-cols-2 gap-4`}>
                  {treatmentPlan.applianceSuggestions.map((group, idx) => (
                    <View key={idx} style={tw`bg-black/30 p-4 rounded-2xl border border-white/5 space-y-2`}>
                      <View style={tw`flex-row justify-between items-center`}>
                        <Text style={tw`text-[9px] font-black text-[#14B8A6] uppercase tracking-wider font-mono`}>
                          {group.category}
                        </Text>
                      </View>
                      <Text style={tw`text-[10px] text-slate-500 leading-normal`}>
                        {group.justification}
                      </Text>
                      <View style={tw`flex-row flex-wrap gap-1.5 pt-1`}>
                        {group.items.map((item, itemIdx) => (
                          <View key={itemIdx} style={tw`bg-white/5 px-2.5 py-1 rounded-lg border border-white/10`}>
                            <Text style={tw`text-[9px] font-bold text-slate-300`}>{item}</Text>
                          </View>
                        ))}
                      </View>
                    </View>
                  ))}
                </View>
              </View>

              {/* Clinician Override and Save Section */}
              <View style={tw`bg-[#0B1020] rounded-3xl p-6 border border-white/5 space-y-4`}>
                <View style={tw`flex-row justify-between items-center border-b border-white/5 pb-3`}>
                  <View style={tw`flex-row items-center space-x-2`}>
                    <Bookmark size={14} color="#14B8A6" />
                    <Text style={tw`text-[10px] font-black text-slate-200 uppercase tracking-widest font-mono`}>
                      CLINICIAN PLAN OVERRIDES & NOTES
                    </Text>
                  </View>
                  <View style={tw`bg-teal-500/10 border border-teal-500/30 px-2 py-0.5 rounded-lg`}>
                    <Text style={tw`text-[7px] text-[#22D3EE] font-mono font-black uppercase tracking-widest`}>Interactive</Text>
                  </View>
                </View>

                <TextInput
                  value={clinicianOverride}
                  onChangeText={setClinicianOverride}
                  multiline
                  numberOfLines={4}
                  placeholder="Enter personalized clinical objectives, diagnostic caveats, or patient-specific instructions to override standard planning recommendations..."
                  placeholderTextColor="#64748B"
                  style={[tw`w-full px-4 py-3.5 bg-black/45 text-slate-100 font-sans text-xs rounded-2xl border border-white/10 focus:border-[#14B8A6]`, { minHeight: 100 }]}
                />

                <Pressable
                  onPress={handleSavePlan}
                  style={({ pressed }) => [
                    tw`w-full py-4 rounded-2xl items-center justify-center shadow-lg border`,
                    isSaved 
                      ? tw`bg-emerald-600 border-emerald-500` 
                      : tw`bg-[#14B8A6] border-teal-400/30 shadow-teal-500/15`,
                    pressed ? tw`opacity-90 scale-98` : null
                  ]}
                >
                  <View style={tw`flex-row items-center space-x-2`}>
                    {isSaved ? (
                      <>
                        <CheckCircle size={14} color="#FFFFFF" />
                        <Text style={tw`text-xs font-black text-white uppercase tracking-widest`}>Plan Updated Successfully</Text>
                      </>
                    ) : (
                      <>
                        <Sparkles size={14} color="#FFFFFF" />
                        <Text style={tw`text-xs font-black text-white uppercase tracking-widest`}>Update & Save Patient Plan</Text>
                      </>
                    )}
                  </View>
                </Pressable>
              </View>

            </View>

          </View>
        )}

      </View>
    </ScrollView>
  );
}
